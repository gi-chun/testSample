//
//  RKMainViewController.m
//  WebDelegateDemo
//
//  Copyright (c) 2014 Ram Kulkarni. All rights reserved.
//

#import "RKMainViewController.h"
#import "WebViewDelegate.h"

@interface RKMainViewController ()
	@property (weak, nonatomic) IBOutlet UITextField *txt1;
	- (IBAction)onAdd:(id)sender;
	@property WebViewDelegate *webViewDelegate;
@end

@implementation RKMainViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	
	self.webViewDelegate = [[WebViewDelegate alloc] initWithWebView:self.webView withWebViewInterface:self];
	
	self.webView.scrollView.scrollEnabled = false;
	[self.webViewDelegate loadPage:@"index.html" fromFolder:@"www"];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (id) processFunctionFromJS:(NSString *) name withArgs:(NSArray*) args error:(NSError **) error
{
	if ([name compare:@"loadList" options:NSCaseInsensitiveSearch] == NSOrderedSame)
	{
		NSArray *listElements = @[@"Item 1", @"Item 2"];
		
		NSData *jsonData = [NSJSONSerialization dataWithJSONObject:listElements options:0 error:nil];
		
		NSString *result = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
		
		return result;
	}

	return nil;
}

- (IBAction)onAdd:(id)sender {
	NSDictionary *dict = @{@"newListItem":self.txt1.text};
		
	[self.webViewDelegate callJSFunction:@"addToList" withArgs:dict];

}
@end
