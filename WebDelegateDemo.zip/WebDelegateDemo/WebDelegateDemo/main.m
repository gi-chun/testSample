//
//  main.m
//  WebDelegateDemo
//
//  Created by Ram on 02/01/14.
//  Copyright (c) 2014 Ram Kulkarni. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "RKAppDelegate.h"

int main(int argc, char * argv[])
{
	@autoreleasepool {
	    return UIApplicationMain(argc, argv, nil, NSStringFromClass([RKAppDelegate class]));
	}
}
