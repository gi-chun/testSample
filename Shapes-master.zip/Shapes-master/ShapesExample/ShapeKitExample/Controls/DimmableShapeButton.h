//
//  DimmableShapedButton.h
//  ShapesExample
//
//  Created by Denys Telezhkin on 30.08.14.
//  Copyright (c) 2014 Denys Telezhkin. All rights reserved.
//

#import "DTShapeButton.h"

@interface DimmableShapeButton : DTShapeButton

@end
