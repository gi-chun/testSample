//
//  AnimatedShapesViewController.h
//  ShapesExample
//
//  Created by Denys Telezhkin on 25.08.14.
//  Copyright (c) 2014 Denys Telezhkin. All rights reserved.
//

#import "HighlightableShapeButton.h"

@interface DownloadButtonViewController : UIViewController

@end
