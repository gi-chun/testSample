//
//  DimmingViewController.h
//  ShapesExample
//
//  Created by Denys Telezhkin on 10.08.14.
//  Copyright (c) 2014 Denys Telezhkin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DimmingViewController : UIViewController

@end
