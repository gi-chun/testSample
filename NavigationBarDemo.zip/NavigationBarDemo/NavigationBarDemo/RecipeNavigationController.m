//
//  RecipeNavigationController.m
//  NavigationBarDemo
//
//  Created by Simon on 2/10/13.
//  Copyright (c) 2013 Appcoda. All rights reserved.
//

#import "RecipeNavigationController.h"

@interface RecipeNavigationController ()

@end

@implementation RecipeNavigationController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// Uncomment to change the status bar style
/*
- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
 */


@end
